<link rel="stylesheet" href="{{asset('backend/assets/css/bootstrap_min.css')}}" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{asset('backend/assets/css/data_table.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/ion_icon.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/template_main.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/template_all_skin.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/datepicker.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/custom_style.css')}}" />

<link href="{{asset('backend/images/logo.png')}}" rel="shortcut icon" />
<link rel="stylesheet" href="{{asset('backend/assets/css/multiple_select_min.css')}}" />
<link rel="stylesheet" href="{{asset('backend/assets/css/bootstrap-timepicker.min.css')}}" />
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->